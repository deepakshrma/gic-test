package com.gic.cinemas.exceptions

class GICException(msg: String) : Exception(msg)